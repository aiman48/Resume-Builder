from flask import Flask, request, render_template
from groq import Groq
import os
from dotenv import load_dotenv

app = Flask(__name__)


load_dotenv()  # Load .env file

groq_api_key = os.getenv("GROQ_API_KEY")
client = Groq(api_key=groq_api_key)

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        name = request.form["name"]
        experience = request.form["experience"]
        skills = request.form["skills"]
        education = request.form["education"]

        prompt = f"""
        Generate a professional resume for the following user:

        Name: {name}
        Experience: {experience}
        Skills: {skills}
        Education: {education}

        Make sure the resume is formal, well-structured, and uses a modern professional tone.
        """

        response = client.chat.completions.create(
            model="llama3-8b-8192",
            messages=[{"role": "user", "content": prompt}]
        )

        resume = response.choices[0].message.content

        return render_template("result.html", name=name, resume=resume)

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
