
## 📝 AI Resume Builder

This is a simple web app that takes your **experience** and **skills**, and generates an AI-powered **resume draft** using the **Grok API**.

### 🔧 Features

* Enter experience and skills
* AI generates a resume
* Attractive HTML output

### 🚀 How to Run

1. Clone or download the project.
2. Install dependencies:

   ```
   pip install -r requirements.txt
   ```
3. Create a `.env` file:

   ```
   GROQ_API_KEY=your_actual_groq_api_key_here
   ```
4. Start the app:

   ```
   python app.py
   ```

